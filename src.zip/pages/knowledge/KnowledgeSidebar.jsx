import React, { useState } from 'react';
import { Layout, Tree, Button } from 'antd';
import {
  StarOutlined,
  ShopOutlined,
  FileOutlined,
  LeftOutlined,
  RightOutlined,
} from '@ant-design/icons';
import './KnowledgeSidebar.scss';

const { Sider } = Layout;

const KnowledgeSidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [expandedKeys, setExpandedKeys] = useState(["product-info", "deposit"]);

  const treeData = [
    {
      title: "IWS",
      key: "iws",
      icon: <StarOutlined style={{ color: "#faad14" }} />,
    },
    {
      title: "Product Information",
      key: "product-info",
      children: [
        { title: "Fund", key: "fund", icon: <FileOutlined /> },
      ],
    },
    {
      title: "Retail Banking",
      key: "retail-banking",
      icon: <ShopOutlined style={{ color: "#1890ff" }} />,
    },
    {
      title: "Deposit",
      key: "deposit",
      children: [
        { title: "7月存款礼包", key: "deposit-july", icon: <FileOutlined /> },
      ],
    },
  ];

  const handleTreeSelect = (selectedKeys, info) => {
    console.log("选择分类:", selectedKeys, info);
  };

  const handleTreeExpand = (expandedKeys) => {
    console.log('展开/折叠状态变化:', expandedKeys);
    setExpandedKeys(expandedKeys);
  };

  return (
    <Sider
      className="knowledge-sidebar"
      width={300}
      collapsed={collapsed}
      collapsible
      trigger={null}
    >
      <div className="sidebar-toggle">
        <Button
          type="text"
          icon={collapsed ? <RightOutlined /> : <LeftOutlined />}
          onClick={() => setCollapsed(!collapsed)}
        />
      </div>

      <div className="sidebar-content">
        <Tree
          className="category-tree"
          treeData={treeData}
          expandedKeys={expandedKeys}
          onExpand={handleTreeExpand}
          onSelect={handleTreeSelect}
          showIcon
          blockNode
        />
      </div>
    </Sider>
  );
};

export default KnowledgeSidebar; 